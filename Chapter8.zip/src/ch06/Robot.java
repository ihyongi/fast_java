package ch06;

public class Robot {

}
