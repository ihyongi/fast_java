package ch06;

public class MazeTest {

	public static void main(String[] args) {

		
	}

}
